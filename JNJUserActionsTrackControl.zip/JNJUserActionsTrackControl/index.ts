import {IInputs, IOutputs} from "./generated/ManifestTypes";


export class JNJUserActionsTrackControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _timer: number;
    private _timeoutDuration: number;
    private _timeOutSign: number;
    private _warnSign: number;
    private _warntime: number;
    private _timeExpireWaring: number;
    private _notifyOutputChanged: () => void;
    /**
     * Empty constructor.
     */
    constructor()
    {
        this._timer = 0;
        this._timeoutDuration = 0;
        this._warntime = 0;
        this._timeExpireWaring = 0;
    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container:HTMLDivElement): void
    {
        // 在此处初始化组件并设置定时器
        this.setProperites(context);
        this._timeExpireWaring = this._timeoutDuration - this._warntime;
        this._notifyOutputChanged = notifyOutputChanged;
        this.registerTimer();
        this.addEventListeners();
    }

    private setProperites(context: ComponentFramework.Context<IInputs>){
        // 在此处初始化组件并设置定时器
        if(context.parameters.TimeOutSpan.raw != null){
            this._timeoutDuration = context.parameters.TimeOutSpan.raw * 1000; 
        }else{
            this._timeoutDuration = 15 * 60 * 1000;// 设置默认超时时间为15分钟
        }
        
        if(context.parameters.WarnSpan.raw != null){
            this._warntime = context.parameters.WarnSpan.raw  * 1000; 
        }else{
            this._warntime = 60 * 1000;// 设置默认提示时间为DDL前1分钟
        }
    }

    private registerTimer(): void {
        console.info("Register timer...")
        // 清除之前的定时器
        clearTimeout(this._timer);
        clearTimeout(this._timeExpireWaring);

        if (this._timeOutSign != 1){
            this._timer = window.setTimeout(() => {
                this.showTimeoutWarning();
            }, this._timeExpireWaring);

            this._timer = window.setTimeout(() => {
                this.processAfterTimeOut();
            }, this._timeoutDuration);
        }
    }


    private showTimeoutWarning(): void {
        // Show the timeout warning message, e.g., display a popup or toast notification
        // For example, display a toast notification:
        console.log("Your session will expire in 1 minute. Please continue your activity.");
        this._warnSign = 1;
        this._notifyOutputChanged();
    }
    

    private processAfterTimeOut(){
        this._timeOutSign = 1;
        this._warnSign = 0;
        this._notifyOutputChanged();
    }

    private resetTimer(): void {
        console.log("===>>>>>>>>>>>>>>>> resetTimer!!!!!!!: " + this._timeOutSign)
        if(this._timeOutSign != 1){
            this.registerTimer();
            this._timeOutSign = 0;
            this._warnSign = 0;
            this._notifyOutputChanged();
        }
    }

    private addEventListeners(): void {
        document.addEventListener("mousedown", this.resetTimer.bind(this));
        document.addEventListener("keydown", this.resetTimer.bind(this));
        document.addEventListener("mousemove", this.resetTimer.bind(this));
    }

    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void
    {
        
        // this._timeOutSign = context.parameters.timeOutSign.raw!;
        // Add code to update control view
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
     */
    public getOutputs(): IOutputs
    {
        console.info("PCFJS:getOutputs " + this._timeOutSign);
        console.info("PCFJS:_warnSign " + this._warnSign);
        return {
            timeOutSign: this._timeOutSign,
            warnSign: this._warnSign
         };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void
    {
        // 在组件销毁时清除定时器和事件监听器
        clearTimeout(this._timer);
        document.removeEventListener("mousedown", this.resetTimer.bind(this));
        document.removeEventListener("keydown", this.resetTimer.bind(this));
        document.removeEventListener("mousemove", this.resetTimer.bind(this));
    }
}

/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    timeOutSign: ComponentFramework.PropertyTypes.DecimalNumberProperty;
    warnSign: ComponentFramework.PropertyTypes.DecimalNumberProperty;
    TimeOutSpan: ComponentFramework.PropertyTypes.DecimalNumberProperty;
    WarnSpan: ComponentFramework.PropertyTypes.DecimalNumberProperty;
}
export interface IOutputs {
    timeOutSign?: number;
    warnSign?: number;
    TimeOutSpan?: number;
    WarnSpan?: number;
}
